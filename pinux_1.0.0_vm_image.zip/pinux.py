import os # 1
print('init drivers at instruction 00005') # -debug
def driver_func(driver): # definintion
    print('load driver \'' + driver + '\'')
    try:
        from importlib import import_module
        return import_module(driver)
    except Exception as e:
        print('exec error in loading driver \'' + driver + '\' with error \'' + str(e) + '\'.')
        os.chdir('C:/')
        os.system('subst X: /d')
        exit()
drivers = [] # add drivers here to get more drivers
loaded_drivers = []
for e in drivers: # for loop counts as definition
    loaded_drivers.append(driver_func(e)) # 5
shell = driver_func('bin.pysh')
print('User: root')
shell.init('root')
os.chdir('C:/')
os.system('subst Y: /d')