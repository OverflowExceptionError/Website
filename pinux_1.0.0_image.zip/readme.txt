PINUX ROOT FILESYSTEM
DO NOT TOUCH

IF TOUCHED, YOU WILL BE FINED 100 US CENTS.


bin: Most important binaries, like pysh.
dev: This contains paths to local filesystem areas like this:
In pysh:
mountfs /dev/sda1 /mount/donovanos

lib: Contains global libraries.
root: Root user folder.
usr: Contains user-centric versions of the bin and lib folders.
mount: Mounting folder. For use with mountfs.

dev folder standard contents:

null
zero
sda0 (Host filesystem) (C:)
sda1 (DonovanOS Filesystem) (Z:)
sda2 (Pinux Filesystem) (X:)