Hello! This is _______ _____ of _______ Science Facilities!
Me and the lab boys have been working on making a one-to-one recreation of the whole _______ Science Facility.
Anyways, what's in this folder of mine is a prototype of this recreation.
And rember:
1. The ice cream is a lie
2. You shouldn't have access to these files
3. This universe is fake
                    ----